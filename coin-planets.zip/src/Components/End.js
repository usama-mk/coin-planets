import React from 'react'
import dinoSkelly from "../assets/dino-skelly.png";


function End() {
  return (
    <div className=' End utilityBG flex justify-center pt-48 pb-32' >
        <img src={dinoSkelly} alt="" />
    </div>
  )
}

export default End